<?php
session_start();
require_once '../includes/auth.php';
requireRole('admin');

$error = '';
$success = '';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'add') {
            $name = trim($_POST['name']);
            $price = floatval($_POST['price']);
            $stock = intval($_POST['stock']);
            $category = trim($_POST['category']);
            $description = trim($_POST['description']);
            $image_url = trim($_POST['image_url']);

            if ($name && $price >= 0 && $stock >= 0) {
                $stmt = $pdo->prepare("INSERT INTO products (name, price, stock, category, description, image_url) VALUES (?, ?, ?, ?, ?, ?)");
                if ($stmt->execute([$name, $price, $stock, $category, $description, $image_url])) {
                    $success = "Product added successfully.";
                } else {
                    $error = "Failed to add product.";
                }
            } else {
                $error = "Please provide valid product details.";
            }
        } elseif ($_POST['action'] === 'delete') {
            $id = intval($_POST['id']);
            $stmt = $pdo->prepare("UPDATE products SET is_active = 0 WHERE id = ?");
            if ($stmt->execute([$id])) {
                $success = "Product removed.";
            } else {
                $error = "Failed to remove product.";
            }
        }
    }
}

// Fetch products
$stmt = $pdo->query("SELECT * FROM products WHERE is_active = 1 ORDER BY id DESC");
$products = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Products</title>
    <link rel="stylesheet" href="../assets/admin.css">
</head>
<body>
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <a href="index.php">Dashboard</a>
        <a href="products.php" class="active">Manage Products</a>
        <a href="transactions.php">Transactions</a>
        <a href="../logout.php">Logout</a>
    </div>
    <div class="main-content">
        <h1>Manage Products</h1>
        <?php if ($error): ?><div style="color:red; margin-bottom:1rem;"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
        <?php if ($success): ?><div style="color:green; margin-bottom:1rem;"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>

        <div style="background:#fff; padding:1.5rem; border-radius:8px; box-shadow:0 2px 4px rgba(0,0,0,0.1); margin-bottom:2rem;">
            <h3>Add New Product</h3>
            <form method="post" action="">
                <input type="hidden" name="action" value="add">
                <div style="display:flex; gap:1rem;">
                    <div class="form-group" style="flex:2">
                        <label>Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="form-group" style="flex:1">
                        <label>Price ($)</label>
                        <input type="number" step="0.01" name="price" class="form-control" required>
                    </div>
                    <div class="form-group" style="flex:1">
                        <label>Stock</label>
                        <input type="number" name="stock" class="form-control" required>
                    </div>
                </div>
                <div style="display:flex; gap:1rem;">
                    <div class="form-group" style="flex:1">
                        <label>Category</label>
                        <input type="text" name="category" class="form-control">
                    </div>
                    <div class="form-group" style="flex:2">
                        <label>Image URL</label>
                        <input type="text" name="image_url" class="form-control" placeholder="../assets/images/example.png">
                    </div>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control" rows="2"></textarea>
                </div>
                <button type="submit" class="btn btn-success">Add Product</button>
            </form>
        </div>

        <h3>Current Products</h3>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $p): ?>
                <tr>
                    <td><?php echo $p['id']; ?></td>
                    <td><?php echo htmlspecialchars($p['name']); ?></td>
                    <td><?php echo htmlspecialchars($p['category']); ?></td>
                    <td>$<?php echo number_format($p['price'], 2); ?></td>
                    <td><?php echo $p['stock']; ?></td>
                    <td>
                        <form method="post" action="" style="display:inline;">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?php echo $p['id']; ?>">
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to remove this product?');">Remove</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (count($products) == 0): ?>
                <tr>
                    <td colspan="6" style="text-align:center;">No active products found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
