<?php
session_start();
require_once '../includes/auth.php';
requireRole('admin');

// Fetch orders with user details
$stmt = $pdo->query("
    SELECT o.id, o.total_amount, o.status, o.created_at, u.name as customer_name, u.email as customer_email
    FROM orders o
    JOIN users u ON o.user_id = u.id
    ORDER BY o.created_at DESC
");
$orders = $stmt->fetchAll();

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $order_id = intval($_POST['order_id']);
    $new_status = $_POST['status'];
    $allowed_statuses = ['pending', 'processing', 'completed', 'cancelled'];
    if (in_array($new_status, $allowed_statuses)) {
        $upd = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $upd->execute([$new_status, $order_id]);
        header("Location: transactions.php?msg=StatusUpdated");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Transactions</title>
    <link rel="stylesheet" href="../assets/admin.css">
</head>
<body>
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <a href="index.php">Dashboard</a>
        <a href="products.php">Manage Products</a>
        <a href="transactions.php" class="active">Transactions</a>
        <a href="../logout.php">Logout</a>
    </div>
    <div class="main-content">
        <h1>Transactions & Orders</h1>
        <?php if (isset($_GET['msg']) && $_GET['msg'] === 'StatusUpdated'): ?>
            <div style="color:green; margin-bottom:1rem;">Order status updated successfully.</div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Date</th>
                    <th>Customer</th>
                    <th>Total ($)</th>
                    <th>Status</th>
                    <th>Update Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $o): ?>
                <tr>
                    <td>#<?php echo $o['id']; ?></td>
                    <td><?php echo date('M d, Y H:i', strtotime($o['created_at'])); ?></td>
                    <td><?php echo htmlspecialchars($o['customer_name']); ?><br><small><?php echo htmlspecialchars($o['customer_email']); ?></small></td>
                    <td>$<?php echo number_format($o['total_amount'], 2); ?></td>
                    <td>
                        <span style="font-weight:bold; color: <?php echo $o['status'] === 'completed' ? 'green' : ($o['status'] === 'cancelled' ? 'red' : 'orange'); ?>">
                            <?php echo ucfirst($o['status']); ?>
                        </span>
                    </td>
                    <td>
                        <form method="post" action="" style="display:flex; gap:0.5rem; align-items:center;">
                            <input type="hidden" name="action" value="update_status">
                            <input type="hidden" name="order_id" value="<?php echo $o['id']; ?>">
                            <select name="status" style="padding:0.25rem;">
                                <option value="pending" <?php if($o['status']=='pending') echo 'selected'; ?>>Pending</option>
                                <option value="processing" <?php if($o['status']=='processing') echo 'selected'; ?>>Processing</option>
                                <option value="completed" <?php if($o['status']=='completed') echo 'selected'; ?>>Completed</option>
                                <option value="cancelled" <?php if($o['status']=='cancelled') echo 'selected'; ?>>Cancelled</option>
                            </select>
                            <button type="submit" class="btn btn-primary btn-sm">Update</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (count($orders) == 0): ?>
                <tr>
                    <td colspan="6" style="text-align:center;">No transactions found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
