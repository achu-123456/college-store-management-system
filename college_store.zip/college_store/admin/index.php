<?php
// admin/index.php
session_start();
require_once '../includes/auth.php';
requireRole('admin');

// Fetch basic stats
$stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role='student'");
$student_count = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM products");
$product_count = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM orders");
$order_count = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT IFNULL(SUM(total_amount), 0) FROM orders WHERE status != 'cancelled'");
$total_revenue = $stmt->fetchColumn();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../assets/admin.css">
</head>
<body>
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <a href="index.php" class="active">Dashboard</a>
        <a href="products.php">Manage Products</a>
        <a href="transactions.php">Transactions</a>
        <a href="../logout.php">Logout</a>
    </div>
    <div class="main-content">
        <h1>Dashboard Overview</h1>
        <div class="cards">
            <div class="card">
                <h3>Students</h3>
                <p><?php echo htmlspecialchars($student_count); ?></p>
            </div>
            <div class="card">
                <h3>Products</h3>
                <p><?php echo htmlspecialchars($product_count); ?></p>
            </div>
            <div class="card">
                <h3>Total Orders</h3>
                <p><?php echo htmlspecialchars($order_count); ?></p>
            </div>
            <div class="card">
                <h3>Revenue</h3>
                <p>$<?php echo number_format($total_revenue, 2); ?></p>
            </div>
        </div>
    </div>
</body>
</html>
