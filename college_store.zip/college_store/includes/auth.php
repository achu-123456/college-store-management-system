<?php
// includes/auth.php
require_once __DIR__ . '/db.php';

function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: /college_store/login.php");
        exit;
    }
}

function requireRole($role) {
    requireLogin();
    if ($_SESSION['role'] !== $role) {
        die("Access denied. You do not have permission to view this page.");
    }
}
?>
