<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireRole('student');

// Handle updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $id = intval($_POST['product_id']);
        if ($_POST['action'] === 'update') {
            $qty = intval($_POST['quantity']);
            if ($qty > 0) {
                $_SESSION['cart'][$id] = $qty;
            } else {
                unset($_SESSION['cart'][$id]);
            }
        } elseif ($_POST['action'] === 'remove') {
            unset($_SESSION['cart'][$id]);
        }
        header("Location: cart.php");
        exit;
    }
}

$cart_items = [];
$total = 0;
if (!empty($_SESSION['cart'])) {
    $ids = implode(',', array_map('intval', array_keys($_SESSION['cart'])));
    $stmt = $pdo->query("SELECT * FROM products WHERE id IN ($ids)");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($products as $p) {
        $p['cart_qty'] = $_SESSION['cart'][$p['id']];
        $p['subtotal'] = $p['price'] * $p['cart_qty'];
        $total += $p['subtotal'];
        $cart_items[] = $p;
    }
}
$cart_count = array_sum($_SESSION['cart'] ?? []);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>College Store - Cart</title>
    <link rel="stylesheet" href="../assets/student.css">
</head>
<body>
    <header class="header">
        <div class="logo">College Store</div>
        <div class="nav">
            <a href="index.php">Catalog</a>
            <a href="cart.php" class="active">Cart (<?php echo $cart_count; ?>)</a>
            <a href="../logout.php">Logout</a>
        </div>
    </header>
    <div class="container">
        <h1>Your Shopping Cart</h1>
        <?php if (empty($cart_items)): ?>
            <p>Your cart is empty. <a href="index.php">Browse products</a></p>
        <?php else: ?>
            <div style="background:#fff; border-radius:8px; box-shadow:0 2px 4px rgba(0,0,0,0.1); padding:1rem;">
                <?php foreach ($cart_items as $item): ?>
                <div class="cart-item">
                    <div style="flex:2">
                        <h3 style="margin:0;"><?php echo htmlspecialchars($item['name']); ?></h3>
                        <p style="margin:0; color:#555;">$<?php echo number_format($item['price'], 2); ?> each</p>
                    </div>
                    <form method="post" action="" style="display:flex; gap:1rem; align-items:center; margin:0;">
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                        <input type="number" name="quantity" value="<?php echo $item['cart_qty']; ?>" min="1" max="<?php echo $item['stock']; ?>" style="width:60px; padding:0.5rem;" onchange="this.form.submit()">
                    </form>
                    <div style="flex:1; text-align:right; font-weight:bold;">
                        $<?php echo number_format($item['subtotal'], 2); ?>
                    </div>
                    <form method="post" action="" style="margin-left:1rem;">
                        <input type="hidden" name="action" value="remove">
                        <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Remove</button>
                    </form>
                </div>
                <?php endforeach; ?>
                <div class="cart-total">
                    Total: $<?php echo number_format($total, 2); ?>
                </div>
                <div style="text-align:right; margin-top:1.5rem;">
                    <a href="checkout.php" class="btn btn-success" style="font-size:1.2rem; padding:1rem 2rem;">Proceed to Checkout</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
