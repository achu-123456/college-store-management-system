<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireRole('student');

if (empty($_SESSION['cart'])) {
    header("Location: index.php");
    exit;
}

$error = '';
$success_order_id = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ids = implode(',', array_map('intval', array_keys($_SESSION['cart'])));
    $stmt = $pdo->query("SELECT * FROM products WHERE id IN ($ids)");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $total = 0;
    foreach ($products as $p) {
        $qty = $_SESSION['cart'][$p['id']];
        if ($qty > $p['stock']) {
            $error = "Not enough stock for " . htmlspecialchars($p['name']);
            break;
        }
        $total += $p['price'] * $qty;
    }
    
    if (!$error) {
        try {
            $pdo->beginTransaction();
            // Insert order
            $stmt = $pdo->prepare("INSERT INTO orders (user_id, total_amount, status) VALUES (?, ?, 'pending')");
            $stmt->execute([$_SESSION['user_id'], $total]);
            $order_id = $pdo->lastInsertId();
            
            // Insert items & reduce stock (use correct column name unit_price as seen in schema.sql)
            $stmt_item = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?)");
            $stmt_stock = $pdo->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
            
            foreach ($products as $p) {
                $qty = $_SESSION['cart'][$p['id']];
                $stmt_item->execute([$order_id, $p['id'], $qty, $p['price']]);
                $stmt_stock->execute([$qty, $p['id']]);
            }
            
            $pdo->commit();
            $_SESSION['cart'] = []; // Clear cart
            $success_order_id = $order_id;
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Order processing failed: " . $e->getMessage();
        }
    }
}

$cart_count = array_sum($_SESSION['cart'] ?? []);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout</title>
    <link rel="stylesheet" href="../assets/student.css">
</head>
<body>
    <header class="header">
        <div class="logo">College Store</div>
        <div class="nav">
            <a href="index.php">Catalog</a>
            <a href="cart.php">Cart (<?php echo $cart_count; ?>)</a>
            <a href="../logout.php">Logout</a>
        </div>
    </header>
    <div class="container">
        <?php if ($success_order_id): ?>
            <div style="background:#fff; padding:3rem; text-align:center; border-radius:8px; box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                <h1 style="color:green;">Order Placed Successfully!</h1>
                <p>Your order ID is <strong>#<?php echo $success_order_id; ?></strong>.</p>
                <p>Thank you for shopping with us!</p>
                <div style="margin-top:2rem;">
                    <a href="invoice.php?order_id=<?php echo $success_order_id; ?>" class="btn btn-primary" target="_blank">Download PDF Invoice</a>
                    <a href="index.php" class="btn btn-secondary" style="margin-left:1rem;">Continue Shopping</a>
                </div>
            </div>
        <?php else: ?>
            <h1>Checkout Completion</h1>
            <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
            
            <div style="background:#fff; padding:2rem; border-radius:8px; box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                <h3>Confirm your order</h3>
                <p>You are about to place an order for the items in your cart.</p>
                <form method="post" action="">
                    <button type="submit" class="btn btn-success" style="font-size:1.2rem; padding:1rem 2rem;">Confirm & Pay</button>
                    <a href="cart.php" class="btn btn-secondary" style="font-size:1.2rem; padding:1rem 2rem; margin-left:1rem;">Back to Cart</a>
                </form>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
