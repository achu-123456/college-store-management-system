<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireRole('student');

// Handle Add to Cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_to_cart') {
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);
    
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id] += $quantity;
    } else {
        $_SESSION['cart'][$product_id] = $quantity;
    }
    header("Location: index.php?msg=AddedToCart");
    exit;
}

// Search functionality
$search = $_GET['search'] ?? '';
if ($search) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE is_active = 1 AND (name LIKE ? OR description LIKE ?) ORDER BY name");
    $stmt->execute(["%$search%", "%$search%"]);
} else {
    $stmt = $pdo->query("SELECT * FROM products WHERE is_active = 1 ORDER BY name");
}
$products = $stmt->fetchAll();

// Calculate cart count
$cart_count = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $qty) {
        $cart_count += $qty;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>College Store - Catalog</title>
    <link rel="stylesheet" href="../assets/student.css">
</head>
<body>
    <header class="header">
        <div class="logo">College Store</div>
        <div class="nav">
            <a href="index.php" class="active">Catalog</a>
            <a href="cart.php">Cart (<?php echo $cart_count; ?>)</a>
            <a href="../logout.php">Logout</a>
        </div>
    </header>
    <div class="container">
        <h1>Product Catalog</h1>
        <?php if (isset($_GET['msg']) && $_GET['msg'] === 'AddedToCart'): ?>
            <div class="alert alert-success">Product added to cart successfully!</div>
        <?php endif; ?>

        <form method="get" action="" class="search-form">
            <input type="text" name="search" placeholder="Search products..." value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn btn-primary">Search</button>
        </form>

        <div class="product-grid">
            <?php foreach ($products as $p): ?>
            <div class="product-card">
                <img src="<?php echo htmlspecialchars($p['image_url'] ?: '../assets/placeholder.jpg'); ?>" alt="Product Image">
                <div class="details">
                    <h3><?php echo htmlspecialchars($p['name']); ?></h3>
                    <p class="category"><?php echo htmlspecialchars($p['category']); ?></p>
                    <p class="price">$<?php echo number_format($p['price'], 2); ?></p>
                    <p class="desc"><?php echo htmlspecialchars(substr($p['description'], 0, 100)) . '...'; ?></p>
                    <?php if ($p['stock'] > 0): ?>
                        <p class="stock">In Stock: <?php echo $p['stock']; ?></p>
                        <form method="post" action="" style="display:flex; gap:0.5rem; margin-top:1rem;">
                            <input type="hidden" name="action" value="add_to_cart">
                            <input type="hidden" name="product_id" value="<?php echo $p['id']; ?>">
                            <input type="number" name="quantity" value="1" min="1" max="<?php echo $p['stock']; ?>" style="width:60px; padding:0.5rem;">
                            <button type="submit" class="btn btn-success" style="flex:1;">Add to Cart</button>
                        </form>
                    <?php else: ?>
                        <p class="stock" style="color:red;">Out of Stock</p>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
            <?php if (count($products) == 0): ?>
                <p>No products found.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
