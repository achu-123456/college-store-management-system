<?php
// student/invoice.php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireRole('student');

// Fallback if composer wasn't successful
if (file_exists('../vendor/autoload.php')) {
    require_once '../vendor/autoload.php';
    $use_dompdf = class_exists('Dompdf\Dompdf');
} else {
    $use_dompdf = false;
}

$order_id = intval($_GET['order_id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$order_id, $_SESSION['user_id']]);
$order = $stmt->fetch();

if (!$order) {
    die("Order not found or access denied.");
}

$ustmt = $pdo->prepare("SELECT name, email FROM users WHERE id = ?");
$ustmt->execute([$_SESSION['user_id']]);
$user = $ustmt->fetch();

$istmt = $pdo->prepare("
    SELECT oi.*, p.name 
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
");
$istmt->execute([$order_id]);
$items = $istmt->fetchAll(PDO::FETCH_ASSOC);

$html = '
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: sans-serif; color: #333; }
        .header { text-align: center; border-bottom: 2px solid #eee; padding-bottom: 1rem; margin-bottom: 2rem; }
        .details { margin-bottom: 2rem; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 0.5rem; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8f9fa; }
        .total { font-weight: bold; font-size: 1.2rem; text-align: right; margin-top: 1rem; }
    </style>
</head>
<body>
    <div class="header">
        <h1>College Store</h1>
        <p>Order Invoice</p>
    </div>
    <div class="details">
        <p><strong>Order ID:</strong> #' . $order['id'] . '</p>
        <p><strong>Date:</strong> ' . date('F j, Y, g:i a', strtotime($order['created_at'])) . '</p>
        <p><strong>Customer:</strong> ' . htmlspecialchars($user['name']) . ' (' . htmlspecialchars($user['email']) . ')</p>
        <p><strong>Status:</strong> ' . ucfirst($order['status']) . '</p>
    </div>
    <table>
        <thead>
            <tr>
                <th>Item</th>
                <th>Price</th>
                <th>Qty</th>
                <th style="text-align:right">Subtotal</th>
            </tr>
        </thead>
        <tbody>';

foreach ($items as $item) {
    $subtotal = $item['unit_price'] * $item['quantity'];
    $html .= '<tr>
        <td>' . htmlspecialchars($item['name']) . '</td>
        <td>$' . number_format($item['unit_price'], 2) . '</td>
        <td>' . $item['quantity'] . '</td>
        <td style="text-align:right">$' . number_format($subtotal, 2) . '</td>
    </tr>';
}

$html .= '
        </tbody>
    </table>
    <div class="total">
        Total Amount: $' . number_format($order['total_amount'], 2) . '
    </div>
</body>
</html>';

if ($use_dompdf) {
    $options = new \Dompdf\Options();
    $options->set('defaultFont', 'Helvetica');
    $options->set('isRemoteEnabled', true);
    
    $dompdf = new \Dompdf\Dompdf($options);
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    
    $dompdf->stream("Invoice_OS_" . $order_id . ".pdf", array("Attachment" => true));
} else {
    // Graceful fallback to browser print view if dompdf is missing
    echo $html;
    echo '<script>window.print();</script>';
}
?>
